from flask import render_template, request, redirect, url_for
from blueprints.auth import auth_bp

# from models import User

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    # TODO: Implementar lógica de login com SQLAlchemy
    return render_template('auth/login.html')


@auth_bp.route('/cadastro', methods=['GET', 'POST'])
def cadastro():

    # boom

    return render_template('auth/register.html')


@auth_bp.route('/logout')
def logout():
    # TODO: Implementar lógica de logout
    return redirect(url_for('auth.login'))
