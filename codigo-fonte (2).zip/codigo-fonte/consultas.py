listar_livros(session)
listar_livros_disponiveis(session)
buscar_livros_por_titulo(session, trecho)
listar_livros_por_autor(session, nome_autor)