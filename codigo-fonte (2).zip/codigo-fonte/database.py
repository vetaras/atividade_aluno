from sqlalchemy import create_engine
from sqlalchemy.orm import Session

engine = create_engine('sqlite:///biblioteca.db')

def criar_banco():
    from models import Base
    Base.metadata.create_all(engine)

def criar_sessao():
    return Session(bind=engine)