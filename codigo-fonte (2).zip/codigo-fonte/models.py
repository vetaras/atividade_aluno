from sqlalchemy import Column, Integer, String, Boolean, ForeignKey
from sqlalchemy.orm import relationship, DeclarativeBase

class Base(DeclarativeBase):
    pass

class Autor(Base):
    __tablename__ = 'autores'

    id = Column(Integer, primary_key=True, autoincrement=True)
    nome = Column(String(50))
    livros = relationship('Livro', back_populates='autor')

class Livro(Base):
    __tablename__ = 'livros'

    id = Column(Integer, primary_key=True, autoincrement=True)
    titulo = Column(String(100))
    autor_id = Column(Integer, ForeignKey('autores.id'))
    disponivel = Column(Boolean, default=True)
    autor = relationship('Autor', back_populates='livros')