from database import criar_sessao
from models import Autor, Livro


session = criar_sessao()

autor1 = Autor(nome='Machado de Assis')
session.add(autor1)
session.commit()

autor2 = Autor(nome='José de Alencar')
autor3 = Autor(nome='Clarice Lispector')
session.add_all([autor2, autor3])
session.commit()

livros = [
    Livro(
        titulo='Dom Casmurro',
        autor=autor1,
        disponivel=True
    ),
    Livro(
        titulo='Memórias Póstumas de Brás Cubas',
        autor=autor1,
        disponivel=False
    ),
    Livro(
        titulo='Quincas Borba',
        autor=autor1,
        disponivel=True
    ),
    Livro(
        titulo='Iracema',
        autor=autor2,
        disponivel=True
    ),
    Livro(
        titulo='Senhora',
        autor=autor2,
        disponivel=False
    ),
    Livro(
        titulo='A Hora da Estrela',
        autor=autor3,
        disponivel=True
    )
]

session.add_all(livros)
session.commit()
session.close()